import React, {useState} from 'react'
import axios from 'axios';
function UserAccessToken() {
    const [error, setError] = useState(false);
    axios.get('http://3.108.244.88:5000/api/user-access-token')
    .then((response)=>{
        const token = response.data;
        console.log("User access token data = ", token.token)
        localStorage.setItem("user-access-token", token.token);
    }).catch(error=>{
        setError(true);
        console.log(error);
    })
  return (
    <div>
        <div>{error && "Error fetching access token"}</div>
        <div>{!error && "Access token retrieved"}</div>
    </div>
  )
}

export default UserAccessToken