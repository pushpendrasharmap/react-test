import React, {useState}from 'react'
import axios from 'axios';
import { useParams } from 'react-router-dom'
function SearchString() {
    const {searchString} = useParams();
    const [result, setResult] = useState([]);
    if(localStorage.getItem("user-access-token") == null){
        return (
            <div>
                First need to fetch Access token
            </div>
        )
    }
    axios.get(`http://3.108.244.88:5000/api/data?${searchString}`, {
        headers:{
            'user-access-token': localStorage.getItem("user-access-token")
        }
    })
    .then((response)=>{
        const data = response.data;
        setResult([...result, data]);
        console.log(response)
    })
        
  return (
    <div>
        <div>
            {
                result.map((entry, index)=>{
                    return (
                        <div>{index}: {entry}</div>
                    )
                })
            }
        </div>
    </div>
  )
}

export default SearchString