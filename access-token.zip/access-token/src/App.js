import logo from './logo.svg';
import './App.css';
import UserAccessToken from './UserAccessToken';
import SearchString from './SearchString';
import { BrowserRouter, Routes, Route } from "react-router-dom";

function App() {
  return (
    <BrowserRouter>
    <Routes>
      <Route path = "/accessToken" element={<UserAccessToken/>}>
        
      </Route>
      <Route path="/searchString/:searchString" element={<SearchString />}>
        
      </Route>
    </Routes>
    </BrowserRouter>
  );
}

export default App;
